./mydbdiff  server2.dev:server1.dev
