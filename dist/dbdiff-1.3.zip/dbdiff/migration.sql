#---------- UP ----------
ALTER TABLE `setting` DEFAULT COLLATE utf8_general_ci;
ALTER TABLE `temp` DEFAULT COLLATE utf8_general_ci;
DROP TRIGGER `test1`;
delimiter //
CREATE DEFINER=`opr`@`%` TRIGGER test1 AFTER INSERT ON group39_dl_items FOR EACH ROW
BEGIN
    INSERT INTO group39_dl_item_changes (itemid, name, checked, checkerid, checktime, creationtime, creationid, assigneeid, assignerid, assigntime, status, statustime, statusid, listid, listtype, mailinglists, disabled, activated, activatetime)
    VALUES (0, new.name, new.checked, new.checkerid, new.checktime, new.creationtime, new.creationid, new.assigneeid, new.assignerid, new.assigntime, new.status, new.statustime, new.statusid, new.listid, new.listtype, new.mailinglists, new.disabled, new.activated, new.activatetime);
END;//
delimiter ;
#---------- DOWN ----------
